using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuitMethod : MonoBehaviour
{
   public void quit(){
    Application.Quit();
   }
}
